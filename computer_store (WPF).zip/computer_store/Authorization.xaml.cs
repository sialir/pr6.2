﻿using computer_store.Pages;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace computer_store
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Page
    {
        private readonly Entities _context = new Entities();

        public Authorization()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (Auth(LoginBox.Text, PasswordBox.Password))
            {
                NavigationService.Navigate(new MainPage());
            }
        }

        public bool Auth(string login, string password)
        {
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            string hashedPassword = HashPassword(password);
            var user = _context.Users.AsNoTracking().FirstOrDefault(u => u.Login == login && u.Password == hashedPassword);

            if (user == null)
            {
                MessageBox.Show("Неверные учетные данные!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            MessageBox.Show("Пользователь успешно найден!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            return true;
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Registration());
        }
    }
}
