﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace computer_store
{
    public partial class Registration : Page
    {
        private readonly Entities _context = new Entities();

        // Добавляем публичное свойство для тестов
        public Entities Context => _context;

        public Registration()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginBox.Text;
            string password = PasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            if (RegisterUser(login, password, confirmPassword))
            {
                MessageBox.Show("Регистрация успешна!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.Navigate(new Authorization());
            }
        }

        public bool RegisterUser(string login, string password, string confirmPassword)
        {
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(confirmPassword))
            {
                return false;
            }

            if (password != confirmPassword)
            {
                return false;
            }

            if (_context.Users.Any(u => u.Login == login))
            {
                return false;
            }

            string hashedPassword = HashPassword(password);

            User newUser = new User
            {
                Login = login,
                Password = hashedPassword,
                RoleID = 2 // 2 = Обычный пользователь (по умолчанию)
            };

            _context.Users.Add(newUser);
            _context.SaveChanges();
            return true;
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        private void BackToLogin_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Authorization());
        }
    }
}
