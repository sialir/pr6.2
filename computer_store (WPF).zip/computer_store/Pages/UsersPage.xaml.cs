﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace computer_store.Pages
{
    /// <summary>
    /// Логика взаимодействия для UsersPage.xaml
    /// </summary>
    public partial class UsersPage : Page
    {
        private readonly Entities _context = Entities.GetContext();
        private computer_store.User selectedUser;

        public UsersPage()
        {
            InitializeComponent();
            LoadData();
            this.IsVisibleChanged += Page_IsVisibleChanged;
        }

        private void LoadData()
        {
            UsersListView.ItemsSource = _context.Users.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.IsVisible && this.IsLoaded)
            {
                LoadData();
            }
        }

        private void ClearForm()
        {
            LoginTextBox.Text = "";
            PasswordTextBox.Text = "";
            RoleIDTextBox.Text = "";
            selectedUser = null;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var user = new computer_store.User
                {
                    Login = LoginTextBox.Text,
                    Password = PasswordTextBox.Text,
                    RoleID = int.Parse(RoleIDTextBox.Text)
                };
                _context.Users.Add(user);
                _context.SaveChanges();
                LoadData();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (selectedUser != null)
            {
                try
                {
                    selectedUser.Login = LoginTextBox.Text;
                    selectedUser.Password = PasswordTextBox.Text;
                    selectedUser.RoleID = int.Parse(RoleIDTextBox.Text);
                    _context.SaveChanges();
                    LoadData();
                    ClearForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при редактировании: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для редактирования", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedUser != null)
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить пользователя?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        _context.Users.Remove(selectedUser);
                        _context.SaveChanges();
                        LoadData();
                        ClearForm();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для удаления", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void UsersListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedUser = UsersListView.SelectedItem as computer_store.User;
            if (selectedUser != null)
            {
                LoginTextBox.Text = selectedUser.Login;
                PasswordTextBox.Text = selectedUser.Password;
                RoleIDTextBox.Text = selectedUser.RoleID.ToString();
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
