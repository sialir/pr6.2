﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace computer_store.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductsPage.xaml
    /// </summary>
    public partial class ProductsPage : Page
    {
        private readonly Entities _context = Entities.GetContext();
        private computer_store.Product selectedProduct;

        public ProductsPage()
        {
            InitializeComponent();
            LoadData();
            this.IsVisibleChanged += ProductsPage_IsVisibleChanged;
        }

        private void ProductsPage_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.IsVisible)
            {
                LoadData();
            }
        }

        private void LoadData()
        {
            ProductsListView.ItemsSource = _context.Products.ToList();
        }

        private void ClearForm()
        {
            ProductNameTextBox.Text = "";
            CategoryIDTextBox.Text = "";
            SupplierIDTextBox.Text = "";
            PriceTextBox.Text = "";
            DescriptionTextBox.Text = "";
            selectedProduct = null;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var product = new computer_store.Product
                {
                    ProductName = ProductNameTextBox.Text,
                    CategoryID = int.Parse(CategoryIDTextBox.Text),
                    SupplierID = int.Parse(SupplierIDTextBox.Text),
                    Price = decimal.Parse(PriceTextBox.Text),
                    Description = DescriptionTextBox.Text
                };

                _context.Products.Add(product);
                _context.SaveChanges();
                LoadData();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении товара: " + ex.Message);
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProduct == null)
            {
                MessageBox.Show("Выберите товар для редактирования.");
                return;
            }

            try
            {
                selectedProduct.ProductName = ProductNameTextBox.Text;
                selectedProduct.CategoryID = int.Parse(CategoryIDTextBox.Text);
                selectedProduct.SupplierID = int.Parse(SupplierIDTextBox.Text);
                selectedProduct.Price = decimal.Parse(PriceTextBox.Text);
                selectedProduct.Description = DescriptionTextBox.Text;

                _context.SaveChanges();
                LoadData();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при редактировании товара: " + ex.Message);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProduct == null)
            {
                MessageBox.Show("Выберите товар для удаления.");
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "Вы уверены, что хотите удалить этот товар?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    _context.Products.Remove(selectedProduct);
                    _context.SaveChanges();
                    LoadData();
                    ClearForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении товара: " + ex.Message);
                }
            }
        }

        private void ProductsListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedProduct = ProductsListView.SelectedItem as computer_store.Product;
            if (selectedProduct != null)
            {
                ProductNameTextBox.Text = selectedProduct.ProductName;
                CategoryIDTextBox.Text = selectedProduct.CategoryID.ToString();
                SupplierIDTextBox.Text = selectedProduct.SupplierID.ToString();
                PriceTextBox.Text = selectedProduct.Price.ToString();
                DescriptionTextBox.Text = selectedProduct.Description;
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
