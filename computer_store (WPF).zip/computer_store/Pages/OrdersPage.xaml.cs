﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace computer_store.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrdersPage.xaml
    /// </summary>
    public partial class OrdersPage : Page
    {
        private readonly Entities _context = Entities.GetContext();
        private computer_store.Order selectedOrder;

        public OrdersPage()
        {
            InitializeComponent();
            LoadData();
            this.IsVisibleChanged += OrdersPage_IsVisibleChanged; // Обновление данных при возвращении на страницу
        }

        private void OrdersPage_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.IsVisible)
            {
                LoadData();
            }
        }

        private void LoadData()
        {
            OrdersListView.ItemsSource = _context.Orders.ToList();
        }

        private void ClearForm()
        {
            CustomerIDTextBox.Text = "";
            OrderDateTextBox.Text = "";
            TotalAmountTextBox.Text = "";
            CreatedByUserIDTextBox.Text = "";
            selectedOrder = null;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!DateTime.TryParse(OrderDateTextBox.Text, out DateTime orderDate))
                {
                    MessageBox.Show("Неверный формат даты.");
                    return;
                }

                if (!int.TryParse(CustomerIDTextBox.Text, out int customerId) ||
                    !_context.Customers.Any(c => c.CustomerID == customerId))
                {
                    MessageBox.Show($"Покупатель с ID {customerId} не найден.");
                    return;
                }

                if (!int.TryParse(CreatedByUserIDTextBox.Text, out int createdByUserId) ||
                    !_context.Users.Any(u => u.UserID == createdByUserId))
                {
                    MessageBox.Show($"Пользователь с ID {createdByUserId} не найден.");
                    return;
                }

                if (!decimal.TryParse(TotalAmountTextBox.Text, out decimal totalAmount))
                {
                    MessageBox.Show("Неверный формат суммы.");
                    return;
                }

                var order = new computer_store.Order
                {
                    CustomerID = customerId,
                    OrderDate = orderDate,
                    TotalAmount = totalAmount,
                    CreatedByUserID = createdByUserId
                };

                _context.Orders.Add(order);
                _context.SaveChanges();
                LoadData();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении заказа: " + ex.Message);
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (selectedOrder == null)
            {
                MessageBox.Show("Выберите заказ для редактирования.");
                return;
            }

            try
            {
                if (!DateTime.TryParse(OrderDateTextBox.Text, out DateTime orderDate))
                {
                    MessageBox.Show("Неверный формат даты.");
                    return;
                }

                if (!int.TryParse(CustomerIDTextBox.Text, out int customerId) ||
                    !_context.Customers.Any(c => c.CustomerID == customerId))
                {
                    MessageBox.Show($"Покупатель с ID {customerId} не найден.");
                    return;
                }

                if (!int.TryParse(CreatedByUserIDTextBox.Text, out int createdByUserId) ||
                    !_context.Users.Any(u => u.UserID == createdByUserId))
                {
                    MessageBox.Show($"Пользователь с ID {createdByUserId} не найден.");
                    return;
                }

                if (!decimal.TryParse(TotalAmountTextBox.Text, out decimal totalAmount))
                {
                    MessageBox.Show("Неверный формат суммы.");
                    return;
                }

                selectedOrder.CustomerID = customerId;
                selectedOrder.OrderDate = orderDate;
                selectedOrder.TotalAmount = totalAmount;
                selectedOrder.CreatedByUserID = createdByUserId;

                _context.SaveChanges();
                LoadData();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при редактировании заказа: " + ex.Message);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedOrder == null)
            {
                MessageBox.Show("Выберите заказ для удаления.");
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "Вы уверены, что хотите удалить этот заказ?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    _context.Orders.Remove(selectedOrder);
                    _context.SaveChanges();
                    LoadData();
                    ClearForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении заказа: " + ex.Message);
                }
            }
        }

        private void OrdersListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedOrder = OrdersListView.SelectedItem as computer_store.Order;
            if (selectedOrder != null)
            {
                CustomerIDTextBox.Text = selectedOrder.CustomerID.ToString();
                OrderDateTextBox.Text = selectedOrder.OrderDate.ToString("yyyy-MM-dd");
                TotalAmountTextBox.Text = selectedOrder.TotalAmount.ToString();
                CreatedByUserIDTextBox.Text = selectedOrder.CreatedByUserID.ToString();
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
