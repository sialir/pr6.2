﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace computer_store.Pages
{
    /// <summary>
    /// Логика взаимодействия для SuppliersPage.xaml
    /// </summary>
    public partial class SuppliersPage : Page
    {
        private readonly Entities _context = Entities.GetContext();
        private computer_store.Supplier selectedSupplier;

        public SuppliersPage()
        {
            InitializeComponent();
            LoadData();
            this.IsVisibleChanged += SuppliersPage_IsVisibleChanged;
        }

        private void SuppliersPage_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.IsVisible)
            {
                LoadData();
            }
        }

        private void LoadData()
        {
            SuppliersListView.ItemsSource = _context.Suppliers.ToList();
        }

        private void ClearForm()
        {
            SupplierNameTextBox.Text = "";
            ContactNameTextBox.Text = "";
            PhoneTextBox.Text = "";
            EmailTextBox.Text = "";
            AddressTextBox.Text = "";
            selectedSupplier = null;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var supplier = new computer_store.Supplier
                {
                    SupplierName = SupplierNameTextBox.Text,
                    ContactName = ContactNameTextBox.Text,
                    Phone = PhoneTextBox.Text,
                    Email = EmailTextBox.Text,
                    Address = AddressTextBox.Text
                };

                _context.Suppliers.Add(supplier);
                _context.SaveChanges();
                LoadData();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении поставщика: " + ex.Message);
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (selectedSupplier == null)
            {
                MessageBox.Show("Выберите поставщика для редактирования.");
                return;
            }

            try
            {
                selectedSupplier.SupplierName = SupplierNameTextBox.Text;
                selectedSupplier.ContactName = ContactNameTextBox.Text;
                selectedSupplier.Phone = PhoneTextBox.Text;
                selectedSupplier.Email = EmailTextBox.Text;
                selectedSupplier.Address = AddressTextBox.Text;

                _context.SaveChanges();
                LoadData();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при редактировании поставщика: " + ex.Message);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedSupplier == null)
            {
                MessageBox.Show("Выберите поставщика для удаления.");
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "Вы уверены, что хотите удалить этого поставщика?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    _context.Suppliers.Remove(selectedSupplier);
                    _context.SaveChanges();
                    LoadData();
                    ClearForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении поставщика: " + ex.Message);
                }
            }
        }

        private void SuppliersListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedSupplier = SuppliersListView.SelectedItem as computer_store.Supplier;
            if (selectedSupplier != null)
            {
                SupplierNameTextBox.Text = selectedSupplier.SupplierName;
                ContactNameTextBox.Text = selectedSupplier.ContactName;
                PhoneTextBox.Text = selectedSupplier.Phone;
                EmailTextBox.Text = selectedSupplier.Email;
                AddressTextBox.Text = selectedSupplier.Address;
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
